#' @param x An \code{mpg_model} object.
#' @param ... Further arguments passed to methods.
#'
#' @export
print.mpg_model <- function(x, ...) {
  if (!inherits(x, "mpg_model") || is.null(x$model)) {
    stop("Object is not a valid 'mpg_model'.")
  }

  cat("Highway MPG Model\n")
  cat("Formula: hwy ~ cty + displ\n\n")
  print(summary(x$model))
  invisible(x)
}

#' Plot diagnostics for mpg_model objects
#'
#' @param x An \code{mpg_model} object.
#' @param ... Further arguments passed to \code{plot.lm}.
#'
#' @export
plot.mpg_model <- function(x, ...) {
  if (!inherits(x, "mpg_model") || is.null(x$model)) {
    stop("Object is not a valid 'mpg_model'.")
  }

  oldpar <- par(no.readonly = TRUE)
  on.exit(par(oldpar))

  plot(x$model, ...)
}
