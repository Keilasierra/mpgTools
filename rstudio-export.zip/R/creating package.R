install.packages(c("usethis", "devtools", "roxygen2", "ggplot2", "rmarkdown", "knitr"))

library(usethis)

usethis::create_package(".")
