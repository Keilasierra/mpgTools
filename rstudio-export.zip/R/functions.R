#' Summarize city and highway MPG
#'
#' @param data A data frame, typically \code{ggplot2::mpg}.
#' @param group_vars Character vector of column names to group by.
#'
#' @return A data frame with mean, sd, and n for city and highway mpg.
#' @export
summarize_mpg <- function(data = ggplot2::mpg,
                          group_vars = c("class", "year")) {
  if (!is.data.frame(data)) {
    stop("`data` must be a data frame.")
  }

  needed <- c("cty", "hwy")
  if (!all(needed %in% names(data))) {
    stop("`data` must contain `cty` and `hwy` columns.")
  }

  if (!all(group_vars %in% names(data))) {
    stop("All `group_vars` must exist in `data`.")
  }

  d <- data[, c(group_vars, "cty", "hwy")]

  agg <- aggregate(
    cbind(cty, hwy) ~ .,
    data = d,
    FUN = function(x) c(mean = mean(x), sd = sd(x), n = length(x))
  )

  out <- do.call(data.frame, agg)

  names(out) <- gsub("cty.", "cty_", names(out), fixed = TRUE)
  names(out) <- gsub("hwy.", "hwy_", names(out), fixed = TRUE)

  out
}

#' Plot city vs highway MPG
#'
#' @param data A data frame, typically \code{ggplot2::mpg}.
#' @param color_var Column name used for color grouping (default "class").
#'
#' @return A ggplot object.
#' @export
plot_city_vs_highway <- function(data = ggplot2::mpg,
                                 color_var = "class") {
  if (!is.data.frame(data)) {
    stop("`data` must be a data frame.")
  }

  needed <- c("cty", "hwy", color_var)
  if (!all(needed %in% names(data))) {
    stop("`data` must contain columns: ", paste(needed, collapse = ", "))
  }

  ggplot2::ggplot(
    data,
    ggplot2::aes_string(x = "cty", y = "hwy", color = color_var)
  ) +
    ggplot2::geom_point(alpha = 0.7) +
    ggplot2::geom_smooth(method = "lm", se = FALSE) +
    ggplot2::labs(
      title = "City vs Highway MPG",
      x = "City MPG",
      y = "Highway MPG",
      color = color_var
    ) +
    ggplot2::theme_minimal()
}

#' Fit a linear model for highway MPG
#'
#' @param data A data frame, typically \code{ggplot2::mpg}.
#'
#' @return An object of class \code{mpg_model}.
#' @export
fit_mpg_model <- function(data = ggplot2::mpg) {
  if (!is.data.frame(data)) {
    stop("`data` must be a data frame.")
  }

  needed <- c("hwy", "cty", "displ")
  if (!all(needed %in% names(data))) {
    stop("`data` must contain columns: ", paste(needed, collapse = ", "))
  }

  fit <- stats::lm(hwy ~ cty + displ, data = data)

  structure(
    list(
      model = fit,
      call  = match.call(),
      data  = data
    ),
    class = "mpg_model"
  )
}
