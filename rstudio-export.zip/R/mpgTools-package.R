#' mpgTools: Tools for Exploring Car Fuel Efficiency
#'
#'
#' @docType package
#' @name mpgTools
NULL
